﻿(async () => {
    await import('file:///X:/机器人/napcat.mjs');
})();
